import { Button } from "./components/ui/button";
import { Input } from "./components/ui/input";
import { Card, CardContent } from "./components/ui/card";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-white text-gray-800">
      <header className="w-full p-4 flex justify-between items-center shadow-md">
        <h1 className="text-2xl font-bold">Găsește-mi Piesa</h1>
        <nav className="space-x-4">
          <a href="#" className="hover:underline">Cum funcționează</a>
          <a href="#" className="hover:underline">Devino furnizor</a>
          <Button>Login</Button>
        </nav>
      </header>

      <section className="text-center py-20 bg-gray-100 px-4">
        <h2 className="text-4xl font-bold mb-4">Cauți o piesă auto?</h2>
        <p className="text-lg mb-6">Completezi formularul. Primesti oferte. Alegi ce ți se potrivește.</p>
        <div className="max-w-xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-2 mb-6">
          <Input placeholder="Marcă" />
          <Input placeholder="Model" />
          <Input placeholder="An" />
          <Input placeholder="Tip piesă" />
        </div>
        <Button className="text-lg px-6 py-2">Cere o piesă acum</Button>
      </section>

      <section className="py-16 px-6 max-w-5xl mx-auto">
        <h3 className="text-3xl font-semibold text-center mb-10">Cum funcționează</h3>
        <div className="grid md:grid-cols-3 gap-8 text-center">
          <Card>
            <CardContent className="p-6">
              <h4 className="text-xl font-bold mb-2">1. Completezi cererea</h4>
              <p>Detalii despre mașină și piesă în 1 minut.</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <h4 className="text-xl font-bold mb-2">2. Primești oferte</h4>
              <p>De la furnizori reali din toată țara, rapid și simplu.</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <h4 className="text-xl font-bold mb-2">3. Alegi și comanzi</h4>
              <p>Compari prețuri, termene și garanții. Comanzi ce e mai bun.</p>
            </CardContent>
          </Card>
        </div>
      </section>

      <section className="text-center py-20 bg-primary text-white">
        <h3 className="text-3xl font-semibold mb-4">Încă mai cauți piesa?</h3>
        <p className="mb-6">Trimite cererea acum și primești oferte în câteva ore.</p>
        <Button variant="secondary" className="text-lg px-6 py-2">Cere o piesă</Button>
      </section>

      <footer className="text-center text-sm text-gray-500 py-6 bg-gray-50">
        &copy; {new Date().getFullYear()} Găsește-mi Piesa. Toate drepturile rezervate.
      </footer>
    </div>
  );
}